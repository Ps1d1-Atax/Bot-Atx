const Discord = require('discord.js')

exports.run = (client, message, args) => {

    ///uptime

    let totalDeSegundos = (client.uptime / 1000)
    let dias = Math.floor(totalDeSegundos / 86400)
    totalDeSegundos %= 86400
    let horas = Math.floor(totalDeSegundos / 3600)
    totalDeSegundos %= 3600
    let minutos = Math.floor(totalDeSegundos / 60)
    let segundos = Math.floor(totalDeSegundos % 60)
    let uptime = `${dias} dias ${horas} horas ${minutos} minutos e ${segundos} segundos`

    ///fim UpTime

let embedStatus = new Discord.MessageEmbed()
        .setTitle('Uptime do Atax!')
        .addFields({name: "Estou Online:", value: `\`${uptime}\``})
        .setColor('BLUE')
        .setThumbnail(client.user.displayAvatarURL())
  message.channel.send(embedStatus)
}