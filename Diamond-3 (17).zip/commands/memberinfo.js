const Discord = require('discord.js')
const moment = require('moment')
moment.locale('pt-BR')
exports.run = (client, message, args) => {
  const user = message.mentions.users.first() || message.author
  const member = message.guild.member(user)

  const embed = new Discord.MessageEmbed()
        .addField(`Usuário:`, `<@${user.id}>`)
        .addField(`Entrou Em:`, `${moment.utc(member.joinedAt).format(`Do MMMM YYYY`)}`)
        .addField(`Conta Criada Em:`, `${moment.utc(user.createdAt).format(`Do MMMM YYYY`)}`)
        .addField('**Nickname**', `${member.nickname !== null ? `Nickname: ${member.nickname}` : 'Nenhum'}`)
        .addField('**Jogando**', `${member.user.presence.game ? `${member.user.presence.game.name}` : ' Nada'}`)
        .setColor(`BLUE`)
        .setThumbnail(user.displayAvatarURL({ format: 'png' }))
    message.channel.send(embed)
}
