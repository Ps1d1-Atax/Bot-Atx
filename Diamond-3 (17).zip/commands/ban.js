const Discord = require("discord.js");
exports.run = (client, message, args) => {
    const user = message.mentions.users.first();

    if (user) {
        const member = message.guild.member(user);
        if (member) {
            member
                .ban({
                    reason: "Não cumpriu com algumas das regras no servidor!",
                })
                .then(() => {
                    const ban = new Discord.MessageEmbed()
                        .setColor("BLUE")
                        .setDescription(`Banido com sucesso ${user.tag}`);
                    message.channel.send(ban);
                })
                .catch((err) => {
                    const erro = new Discord.MessageEmbed()
                        .setColor("BLUE")
                        .setDescription(`Não foi possivel banir.`);
                    message.channel.send(erro);
                    console.error(err);
                });
        } else {
            const none = new Discord.MessageEmbed()
                .setColor("BLUE")
                .setDescription("Este usuário não se encontra no servidor.");
            message.channel.send(none);
        }
    } else {
        const no = new Discord.MessageEmbed()
            .setColor("BLUE")
            .setDescription("Você não mencionou qual membro quer banir");
        message.channel.send(no);
    }
    if (!message.member.permissions.has("BAN_MEMBERS")) {
        const perm = new Discord.MessageEmbed()
            .setColor("BLUE")
            .setDescription("Você não tem permissão para banir!");
        return message.reply(perm);
    }
}