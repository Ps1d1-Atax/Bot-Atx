const Discord = require('discord.js')
const os = require("os-utils")

exports.run = (client, message, args) => {

    const ram = process.memoryUsage().rss / (1024 * 1024)

    const ping = Date.now() - message.createdTimestamp

    ///uptime

    let totalDeSegundos = (client.uptime / 1000)
    let dias = Math.floor(totalDeSegundos / 86400)
    totalDeSegundos %= 86400
    let horas = Math.floor(totalDeSegundos / 3600)
    totalDeSegundos %= 3600
    let minutos = Math.floor(totalDeSegundos / 60)
    let segundos = Math.floor(totalDeSegundos % 60)
    let uptime = `${dias} dias ${horas} horas ${minutos} minutos e ${segundos} segundos`

    ///fim UpTime

    let embedStatus = new Discord.MessageEmbed()
        .setTitle('Stats full do Atax')
        .addFields(

            { name: "<:hypesquadevents:556682499569221662>┃ID/Nome", value: "`Atax Bot#9747/793209882739605534`" },

            { name: "<:online:556678187786960897>┃Countainer", value: "`online`"},

            { name: "<:partner:556680355277438977>┃Linguagem", value: "`JavaScript(JS)`"},

            { name: "<:partner2:767235399943979038>┃Estou Online:", value: `\`${uptime}\``},

            { name: "<:stafftools:771327236950982696>┃Memória Ram Usada:", value: ` \`${Math.round(ram * 100) / 100}mb \`` },

            { name: "<:bughunter_lvl2:771327778791882764>┃Ping:", value: `\`Latência do Servidor: ${ping}ms\nLatência da API: ${Math.round(client.ws.ping)}ms\`` },

            { name: "<a:loading:556680890311507978>┃Prefixo", value: "`x!`"},

            { name: "<:boost4:773545956519706644>┃Ssd", value: "`1.26(gb)`"},

            { name: "<:dev_verificado:769314927105146921>┃OS", value: "`Windows 10 home single user`"},

            { name:"<:new_verified:784396358496682004>┃Hospedagem", value:"`Discloud CloudAcess PT_BR free`"},

            {name:"<a:cursor:556681014479552512>┃Pasta de comandos", value:"`commands/17`"}
        )
        .setThumbnail('https://cdn.discordapp.com/avatars/793209882739605534/b1504f55d407b42b13becb933764aa80.png')
        .setColor('BLUE')
    message.channel.send(embedStatus)

}