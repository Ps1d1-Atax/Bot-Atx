const Discord = require('discord.js');

exports.run = async (client, message, args) => {
  
const perms = message.member.permissions.has("MANAGE_ROLES")
if(!perms) return message.reply("Você nao tem permissão para fazer isso!")
  
  let role = message.mentions.roles.first()
  if(!role) return message.reply("**<:hypesquadevents:556682499569221662> I Este cargo nao existe, use um que seja inferior ao meu e não use id.s, somente @**")
  let member = message.mentions.members.first()
  if(!member) return message.reply("**<:earlysupporter:556682087579516968> I Mencione um usuario que tenha cargos inferiores ao meu e não use id.s, mas sim @!**")
 try {
  member.roles.remove(role.id)
  message.channel.send("**<:new_verified:784396358496682004> I Cargo removido sem exitôs!**")
  
}catch(err) {
 console.error(err)
}
}