const Discord = require("discord.js");

exports.run = async (bot,message,args) => {
    if (!message.member.roles.cache.has('Misty Staff') && !message.member.hasPermission("ADMINISTRATOR")) {
        return message.channel.send("<:xmark:645985214652350505> **|** Você não tem permissão para executar esse comando!");
    }
    
    const channel  = message.mentions.channels.first() || message.channel;
    const roles    = message.guild.roles.cache;
    const everyone = roles.find(role => role.name === "@everyone");

    await channel.overwritePermissions([
        {
            id: everyone,
            allow: ["SEND_MESSAGES"]
        }
    ]);
//créditos zUnKx
    const msg = new Discord.MessageEmbed()
        .setColor("BLUE")
        .setTitle('\ <:enabled:556679191349690388>**|** Ativo novamente!')
        .setDescription(`Canal desbloquado sem exitôs, podem voltar a badernar!, **[<#${channel.id}>]**`)


    return message.channel.send(msg);
};

exports.config = {
    name: 'chaton',
    aliases: ['rchat', 'chat on', 'unlock']
}