const Discord = require('discord.js')
exports.run = (client, message, args) => {
    let embed = new Discord.MessageEmbed()
        .setTitle('Informações')
        .setDescription(`**🤖 Versão:** 1.4.0\n\n**⚙️ Patch:** [Patch AddRole]`)
        .setColor('BLUE')
  message.channel.send(embed)
}