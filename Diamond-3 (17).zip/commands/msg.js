const Discord = require('discord.js')
exports.run = (client, message, args) => {
    if(!message.member.hasPermission('ADMINISTRATOR')) return
    message.delete()
    let embed = new Discord.MessageEmbed()
        .setTitle('Patch [Patch AddRole]')
        .setDescription(`**Update:** 1.4.0\n\n**Adições:**\n\n+comando **x!addrole @user @role** adicionado

        +comando **x!r-role @user @role** adicionado

        +**Buff** no comando **x!memberinfo**
        ( @everyone )`)
        .setColor('BLUE')
        .setThumbnail(client.user.displayAvatarURL())
    message.channel.send(embed)
}