const Discord = require("discord.js");
exports.run = (client, message, args) => {
    const user = message.mentions.users.first();

    if (user) {
        const member = message.guild.member(user);
        if (member) {
            member
                .kick({
                    reason: "Não cumpriu com algumas das regras no servidor!",
                })
                .then(() => {
                    const kick = new Discord.MessageEmbed()
                        .setColor("BLUE")
                        .setDescription(`Expulso com sucesso ${user.tag}`);
                    message.channel.send(kick);
                })
                .catch((err) => {
                    const erro = new Discord.MessageEmbed()
                        .setColor("BLUE")
                        .setDescription(`Não foi possivel expulsar.`);
                    message.channel.send(erro);
                    console.error(err);
                });
        } else {
            const none = new Discord.MessageEmbed()
                .setColor("BLUE")
                .setDescription("Este usuário não se encontra no servidor.");
            message.channel.send(none);
        }
    } else {
        const no = new Discord.MessageEmbed()
            .setColor("BLUE")
            .setDescription("Você não mencionou qual membro quer expulsar");
        message.channel.send(no);
    }
    if (!message.member.permissions.has("KICK_MEMBERS")) {
        const perm = new Discord.MessageEmbed()
            .setColor("#000000")
            .setDescription("Você não tem permissão para expulsar!");
        return message.reply(perm);
    }
}