const Discord = require('discord.js')
exports.run = (client, message, args) => {
    let embed = new Discord.MessageEmbed()
        .setDescription(`
       **<:dev_verificado:769314927105146921> I Moderação**
       1. x!ban **@user**
       2. x!kick **@user**
       3. x!clear **<quantia de 2 a 99>**
       4. x!lock **canal**
       5. x!unlock **canal**
       6. x!addrole **@user "não use id"** **@role "não usar id"**
       7. x!r-role **@user "não use id"** **@role "não usar id"**

       **<:hypesquad:556680458411311114> I Informações**
       1. x!ping
       2. x!memberinfo **@user(opicional)**

       **<:bughunter_lvl2:771327778791882764> I Utilitarios** 
       1. x!avatar **@user(opicional)**
       2. x!say **(mensagem)**

       **<:earlysupporter:556682087579516968> I Bot Info**
       1. x!help
       2. x!support
       3. x!version
       4. x!uptime
       5. x!sfull

       Meu prefix é x!...
       `)
        .setColor('BLUE')
  message.channel.send(embed)
}