const Discord = require('discord.js')
exports.run = (client, message, args) => {
    let embed = new Discord.MessageEmbed()
        .setTitle('Confira o servidor de suporte !')
        .setDescription(`
        
        Servidor de suporte 
        
        
        https://discord.gg/JwEdnuMtmA
        `)
        .setColor('BLUE')
  message.channel.send(embed)
}